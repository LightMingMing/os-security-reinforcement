./configure --prefix=/usr/local/nginx --with-pcre=/root/nginx/pcre-8.42 --with-openssl=/root/nginx/openssl-1.0.2l --with-http_stub_status_module --with-http_ssl_module && make && make install
echo 'ok'
