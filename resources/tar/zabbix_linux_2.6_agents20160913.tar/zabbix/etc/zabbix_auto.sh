#!/bin/sh
groupadd zabbix
useradd -g zabbix -M -s /sbin/nologin zabbix
chown -R zabbix.zabbix /usr/local/zabbix
sed -i s/172.16.2.58/$1/g /usr/local/zabbix/conf/zabbix_agentd.conf
/usr/local/zabbix/sbin/zabbix_agentd -c /usr/local/zabbix/conf/zabbix_agentd.conf 

################Ô¼ӿª»ú¶¯
chmod a+x /etc/rc.d/rc.local
echo "/usr/local/zabbix/sbin/zabbix_agentd -c /usr/local/zabbix/conf/zabbix_agentd.conf" >> /etc/rc.d/rc.local

################ÅÖһ¸öntab
echo "* * * * * /root/iostat_check.sh" >> /var/spool/cron/root
echo "/usr/bin/iostat -m -x -d 1 3  > /tmp/iostat.out" > /root/iostat_check.sh
chmod +x /root/iostat_check.sh

################Ô¼ÓessageµÄabbix·ÃÊ¨Ï
setfacl -m u:zabbix:r -- /var/log/messages
