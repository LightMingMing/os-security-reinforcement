#!/bin/bash 
DISK_NAME="$1" 
PARAM="$2"
case $2 in 
IOBUSY)
     cat /tmp/iostat.out|grep -w $DISK_NAME|tail -1 |awk '{print $12}';; 
RSPEED) 
     cat /tmp/iostat.out|grep -w $DISK_NAME|tail -1 |awk '{print $6}';; 
WSPEED) 
     cat /tmp/iostat.out|grep -w $DISK_NAME|tail -1 |awk '{print $7}';; 
*) 
     echo "PARAM ERROR"; exit 1;; 
esac 
exit 0
