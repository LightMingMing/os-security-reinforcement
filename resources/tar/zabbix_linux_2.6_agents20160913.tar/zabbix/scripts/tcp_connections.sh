#!/bin/bash
num1=`netstat -an|awk '/^tcp/{++S[$NF]}END{for(a in S) print a, S[a]}'|grep $1|awk '{print $2}'`
num=$num1"aaaa"
if [ $num = "aaaa" ];then
     echo 0
else
     echo $num1
fi
