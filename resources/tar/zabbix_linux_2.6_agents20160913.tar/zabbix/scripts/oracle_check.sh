#!/bin/bash 
EQ_DATA="$2" 
ZBX_REQ_DATA_TAB="$1" 
SOURCE_DATA=/tmp/tablespace.log 
case $2 in 
maxmb) grep -Ew "$ZBX_REQ_DATA_TAB" $SOURCE_DATA |awk '{print $5}';; 
used) grep -Ew "$ZBX_REQ_DATA_TAB" $SOURCE_DATA |awk '{print $6}';; 
autopercent) grep -Ew "$ZBX_REQ_DATA_TAB" $SOURCE_DATA |awk '{print $7}';; 
*) echo $ERROR_WRONG_PARAM; exit 1;; 
esac 
exit 0 
