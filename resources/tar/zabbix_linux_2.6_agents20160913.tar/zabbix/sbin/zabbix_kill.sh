#!/bin/bash
ps -ef|grep zabbix|grep -v grep |grep zabbix_agentd|awk '{print "kill -9 "$2}'|sh
