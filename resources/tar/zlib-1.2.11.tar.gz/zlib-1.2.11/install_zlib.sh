./configure && make && make install
echo 'ok'
